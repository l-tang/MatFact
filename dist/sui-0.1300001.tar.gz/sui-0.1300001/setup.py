from setuptools import setup
setup(name='sui',
      version='0.1300001',
      description='some useful implementations',
      url='http://github.com/l-tang/SUI',
      author='Li Tang',
      author_email='litang1025@gmail.com',
      license='MIT',
      packages=['sui'],
      zip_safe=False)
