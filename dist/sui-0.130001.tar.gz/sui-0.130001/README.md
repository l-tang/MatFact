# SUI
SUI(Some Useful Implementations) is a peckage including selected implementations apropos machine learning, deep learning, and reinforcement learning algorithms.

## 1. Install
`pip install sui`


Dear Miss Sui Lin,

I love you!
