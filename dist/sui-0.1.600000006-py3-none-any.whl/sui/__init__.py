from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from ml.mf import *

__author__ = ['Li Tang']
__copyright__ = 'Li Tang'
__credits__ = ['Li Tang']
__license__ = 'MIT'
__version__ = '0.1.6'
__maintainer__ = ['Li Tang']
__email__ = 'litang1025@gmail.com'
__status__ = 'Production'

my_dear = "Dear Miss Sui Lin, I love you!"
