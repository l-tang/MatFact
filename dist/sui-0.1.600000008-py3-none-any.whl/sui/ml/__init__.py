"""sui.ml
Machine learning algorithm implementations
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

model_class_list = ["sui.ml.mf.FunkSVD() => FunkSVD"]
